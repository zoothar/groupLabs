public class MainApp
{ 
    public static void main(String[] args) {
        int unusedVariable = 0;
        System.out.println("Hello World! ^__^");
	System.out.print(unusedVariable);
	obj = new App();
	System.out.print(obj.unusedfield);
	System.out.print(obj.unusedMethod());
	}
}
