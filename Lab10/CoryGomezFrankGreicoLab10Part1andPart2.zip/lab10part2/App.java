public class App
{     
    private int unusedfield;
    private String unusedMethod(){
    return "Test";
    } 
} 
