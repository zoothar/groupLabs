class CreateStudents < ActiveRecord::Migration
  def change
    create_table :students do |t|
      t.string :frank     , null: false
      t.string :greico   ,  null: false
      t.string :username , null: false
      t.string :email  ,         null: false
      t.timestamps null: false
    add_index :students, :email, unique: true
    add_index :students, :username, unique: true
    end
  end
end
